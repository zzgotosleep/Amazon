<?php 
$send="your email here";//PUT YOUR EMAIL BROO ! :v 

?>